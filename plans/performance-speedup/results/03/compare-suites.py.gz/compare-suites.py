"""One confirmation across the immutable request, dispatch and HTTP series."""
from pathlib import Path
import subprocess


ROOT = Path(__file__).resolve().parents[4]
PROTO = '/home/ubuntu/workspace/zebra/plans/performance-speedup/results/01'
for suite in ['request', 'dispatch', 'http']:
    subprocess.run([
        'python3', PROTO + '/series.py',
        '--harness', '/home/ubuntu/workspace/zebra/bench/hot-path.ts',
        '--before', '/tmp/zebra-performance-speedup-01/baseline-a856cab',
        '--after', str(ROOT), '--suite', suite,
    ], cwd=ROOT, check=True)
