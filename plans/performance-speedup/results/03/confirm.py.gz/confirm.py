"""Two fixed confirmations per suite/runtime; invoke under the measure lock."""
import json
import gzip
import os
from pathlib import Path
import subprocess


OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
PROTO = Path('/home/ubuntu/workspace/zebra/plans/performance-speedup/results/01')
HARNESS = '/home/ubuntu/workspace/zebra/bench/hot-path.ts'
BASELINE = '/tmp/zebra-performance-speedup-01/baseline-a856cab'


def main():
    # Controls must be fixed before the first candidate timing on 1.4.0.
    assert (OUT / 'controls-140-decision.txt').exists()
    for version in ['142', '140']:
        checks = [json.loads(line) for line in
                  (OUT / f'candidate-{version}-commands.jsonl').read_text().splitlines()]
        assert checks[-1]['command'] == ['git', 'diff', '--check']
        assert all(row['exit'] == 0 for row in checks), 'Fix candidate validation before timing'
    assert gzip.decompress((OUT / 'candidate-request.ts.gz').read_bytes()) == (
        ROOT / 'packages/core/src/http/request.ts').read_bytes()
    for version, binary in [
        ('142', '/home/ubuntu/.bun/bin'),
        ('140', '/tmp/zebra-performance-speedup-01/runtime/bun-1.4.0'),
    ]:
        env = {**os.environ, 'PATH': binary + ':' + os.environ['PATH']}
        for confirmation in [1, 2]:
            out = OUT / f'candidate-{version}-{confirmation}'
            command = ['python3', str(PROTO / 'measure.py'), '--output', str(out),
                       'python3', str(OUT / 'compare-suites.py')]
            result = subprocess.run(command, cwd=ROOT, env=env, check=False)
            print(json.dumps({'run': out.name, 'exit': result.returncode}), flush=True)
        out = OUT / f'historical-{version}'
        subprocess.run(['python3', str(PROTO / 'measure.py'), '--output', str(out),
                        'bun', 'run', 'bench:check'], cwd=ROOT, env=env, check=False)
    for pattern in ['candidate-*', 'historical-*']:
        for directory in OUT.glob(pattern):
            if not directory.is_dir():
                continue
            for name in ['stdout.log', 'stderr.log', 'load.jsonl', 'status.json']:
                path = directory / name
                if path.is_file():
                    path.with_name(name + '.gz').write_bytes(gzip.compress(path.read_bytes(), mtime=0))
                    path.unlink()


if __name__ == '__main__':
    main()
