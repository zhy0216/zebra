"""Bounded prospective Bun 1.4.0 A/A controls; invoke under the measure lock."""
import csv
import json
from pathlib import Path
import statistics
import subprocess


OUT = Path(__file__).resolve().parent
PROTO = Path('/home/ubuntu/workspace/zebra/plans/performance-speedup/results/01')
HARNESS = '/home/ubuntu/workspace/zebra/bench/hot-path.ts'
BASELINE = '/tmp/zebra-performance-speedup-01/baseline-a856cab'
EXPECTED_SOURCE = '7a9eb1077326654812aabcad8519086ce61b28350a6160582ec01cbce90c9b73'
EXPECTED_HARNESS = 'b4a3feb23f5d26c8b6121d35e1b121b2b5ab6221b45a62ae4ddf42dd8a31a976'


def main():
    envelopes = []
    decisions = {}
    for suite in ['request', 'http']:
        decisions[suite] = 'inconclusive: no eligible control within two attempts'
        for attempt in [1, 2]:
            out = OUT / f'aa-140-{suite}-{attempt}'
            command = ['python3', str(PROTO / 'measure.py'), '--output', str(out),
                       'python3', str(PROTO / 'series.py'), '--harness', HARNESS,
                       '--before', BASELINE, '--after', BASELINE, '--suite', suite]
            subprocess.run(command, check=False)
            status = json.loads((out / 'status.json').read_text())
            if not status.get('eligible'):
                continue
            records = [json.loads(line) for line in (out / 'stdout.log').read_text().splitlines()]
            envs = [r for r in records if r['type'] == 'environment']
            assert len(envs) == len({r['pid'] for r in envs}) == 10
            assert all(r['runtime']['bun'] == '1.4.0' for r in envs)
            assert all(r['source']['productionSha256'] == EXPECTED_SOURCE for r in envs)
            assert all(r['harness']['sha256'] == EXPECTED_HARNESS for r in envs)
            assert all(not r['harness']['diff'] for r in envs)
            assert len({r['source']['lockSha256'] for r in envs}) == 1
            assert len([r for r in records if r['type'] == 'complete' and r['ok']]) == 10
            assert len([r for r in records if r['type'] == 'exit' and r['code'] == 0]) == 10
            for pair in range(1, 6):
                assert [r['side'] for r in envs if r['pair'] == pair] == (
                    ['A', 'B'] if pair % 2 else ['B', 'A'])
            rows = {}
            for row in records:
                if row['type'] != 'round':
                    continue
                for metric in (['rps', 'p50', 'p95', 'p99'] if suite == 'http' else ['nsPerOp']):
                    rows.setdefault((row['name'], metric), {})[row['side'], row['pair']] = row[metric]
            for (name, metric), values in rows.items():
                assert len(values) == 10
                changes = [100 * (values['B', i] / values['A', i] - 1) for i in range(1, 6)]
                absolute = list(map(abs, changes))
                envelope = max(5, max(absolute))
                envelopes.append({'bun': '1.4.0', 'suite': suite, 'fixture': name,
                                  'metric': metric, 'samples': 5,
                                  'median_abs_pair_pct': statistics.median(absolute),
                                  'p90_abs_pair_pct': max(absolute), 'envelope_pct': envelope,
                                  'noisy': envelope > 20, 'control': out.name,
                                  'paired_changes_pct': json.dumps(changes)})
            decisions[suite] = f'fixed from {out.name}; no replacement allowed'
            break
    fields = ['bun', 'suite', 'fixture', 'metric', 'samples', 'median_abs_pair_pct',
              'p90_abs_pair_pct', 'envelope_pct', 'noisy', 'control', 'paired_changes_pct']
    with (OUT / 'controls-140.csv').open('x') as file:
        writer = csv.DictWriter(file, fieldnames=fields, lineterminator='\n')
        writer.writeheader()
        writer.writerows(envelopes)
    (OUT / 'controls-140-decision.txt').write_text(json.dumps(decisions, indent=2) + '\n')
    print(json.dumps(decisions), flush=True)


if __name__ == '__main__':
    main()
