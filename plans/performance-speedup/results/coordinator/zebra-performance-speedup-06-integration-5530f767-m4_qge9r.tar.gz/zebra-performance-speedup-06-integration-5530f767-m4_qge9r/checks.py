"""Run inside one coordinator check allocation; evidence stays outside the tree."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

OUT=Path(__file__).resolve().parent
ROOT=Path.cwd()
BASE='5530f7678a9df0c92fcdf9e99c268408c913a439'
runtime=sys.argv[1]
env=os.environ.copy()
env['PATH']=({'142':'/home/ubuntu/.bun/bin','140':'/tmp/zebra-performance-speedup-01/runtime/bun-1.4.0'}[runtime]+':'+env['PATH'])
env['DOCS_BASE']='/zebra/'

def git(*args):
 return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()

def verify_bytes():
 saved=json.loads((OUT/'reviewed-files.json').read_text())
 files=git('ls-files').splitlines()
 assert set(files)==set(saved)
 changed=[name for name in files if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=saved[name]]
 assert not changed,changed
 assert git('status','--porcelain')==''
 assert git('rev-list','--count',BASE+'..HEAD')=='1'
 return {'trackedFiles':len(files),'reviewedBytesUnchanged':True,'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--porcelain')}

before=verify_bytes()
commands=[('version',['bun','--version']),('revision',['bun','--revision']),('typecheck',['bun','run','typecheck']),('lint',['bun','run','lint']),('docs',['bun','run','docs:build']),('diff',['git','diff','--check',BASE,'HEAD']),('working-diff',['git','diff','--check','HEAD'])]
for label,command in commands:
 record={'label':label,'runtime':runtime,'command':command,'cwd':str(ROOT),'PATH':env['PATH'],'DOCS_BASE':env['DOCS_BASE'],'executable':shutil.which('bun',path=env['PATH']),'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'started':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 result=subprocess.run(command,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 log=OUT/f'{label}-{runtime}.log'
 assert not log.exists()
 log.write_bytes(result.stdout)
 record.update(exit=result.returncode,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),log=str(log),rawSha256=hashlib.sha256(result.stdout).hexdigest())
 with (OUT/f'checks-{runtime}.jsonl').open('a') as stream:
  stream.write(json.dumps(record)+'\n')
 print(f'{runtime} {label}: exit {result.returncode}; {log}',flush=True)
 if result.returncode:
  print(result.stdout.decode(errors='replace'),flush=True)
  raise SystemExit(result.returncode)
after=verify_bytes()
(OUT/f'preservation-{runtime}.json').write_text(json.dumps({'before':before,'after':after},indent=2)+'\n')
print(f'{runtime}: all {after["trackedFiles"]} tracked files preserve reviewed bytes; tree clean',flush=True)
