"""Run only the authorized integration checks; caller holds run-load.py check."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
worktree = Path('/home/ubuntu/.herdr/worktrees/zebra/herdr-plan-performance-speedup-05-dispatch')
base = 'd04aeafda1a3379e5ad5e06c742d0e3923c03034'
harness = '/home/ubuntu/workspace/zebra/bench/hot-path.ts'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree, text=True).strip()
commands = [
    ('focused', ['bun', 'test', 'packages/core/test/app', 'packages/core/test/middleware', 'packages/core/test/contract', 'packages/core/test/ws.test.ts', 'packages/session/test', 'packages/observability/test']),
    ('harness', ['bun', harness, '--source-root', str(worktree), '--suite', 'all', '--check']),
    ('typecheck', ['bun', 'run', 'typecheck']),
    ('lint', ['bun', 'run', 'lint']),
    ('diff', ['git', 'diff', '--check', base, 'HEAD']),
]
failed = False
for runtime, binary in [('142', '/home/ubuntu/.bun/bin'), ('140', '/tmp/zebra-performance-speedup-01/runtime/bun-1.4.0')]:
    env = os.environ.copy()
    env['PATH'] = binary + os.pathsep + env['PATH']
    for label, command in commands:
        log = root / f'{label}-{runtime}.log'
        assert not log.exists()
        record = {'label': f'{label}-{runtime}', 'command': command, 'cwd': str(worktree), 'PATH': env['PATH'], 'head': head, 'base': base, 'started': datetime.datetime.now(datetime.timezone.utc).isoformat()}
        with log.open('wb') as output:
            result = subprocess.run(command, cwd=worktree, env=env, stdout=output, stderr=subprocess.STDOUT)
        data = log.read_bytes()
        record.update({'exit': result.returncode, 'finished': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'log': str(log), 'rawSha256': hashlib.sha256(data).hexdigest(), 'worktreeStatusAfter': subprocess.check_output(['git', 'status', '--porcelain'], cwd=worktree, text=True)})
        with (root / 'checks.jsonl').open('a') as output:
            output.write(json.dumps(record) + '\n')
        print(json.dumps(record), flush=True)
        print(data.decode(errors='replace')[-1600:], flush=True)
        failed |= bool(result.returncode)
raise SystemExit(int(failed))
