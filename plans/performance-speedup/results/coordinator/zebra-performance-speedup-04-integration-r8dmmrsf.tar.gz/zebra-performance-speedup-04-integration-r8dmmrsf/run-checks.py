"""Run task 04 integration checks under one outer run-load.py check lock."""
import datetime
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
root = Path('/home/ubuntu/.herdr/worktrees/zebra/herdr-plan-performance-speedup-04-di')
out = Path(__file__).resolve().parent
target = '01a5ca69330aa0f52dbd7f7d1513a9b77fb7e1d6'
git = lambda *args: subprocess.check_output(['git', *args], cwd=root)
head = git('rev-parse', 'HEAD').decode().strip()
assert git('rev-parse', 'HEAD^').decode().strip() == target
assert not git('status', '--porcelain=v1')
spec = importlib.util.spec_from_file_location('task04_checks', root / 'plans/performance-speedup/results/04/checks.py')
checks = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checks)
checks.OUT = out
original_path = os.environ['PATH']
failed = False
runtimes = []
for version, label, prefix in [
    ('1.4.2', '142', '/home/ubuntu/.bun/bin'),
    ('1.4.0', '140', '/tmp/zebra-performance-speedup-01/runtime/bun-1.4.0'),
]:
    os.environ['PATH'] = prefix + ':' + original_path
    runtime = {'expected': version, 'version': subprocess.check_output(['bun', '--version'], text=True).strip(),
               'revision': subprocess.check_output(['bun', '--revision'], text=True).strip(),
               'PATH': os.environ['PATH']}
    assert runtime['version'] == version
    sys.argv = [str(spec.origin), '--label', f'integration-{label}', '--mode', 'final-source']
    runtime['exit'] = checks.main()
    failed |= runtime['exit'] != 0
    runtimes.append(runtime)
command = ['git', 'diff', '--check', target, head]
result = subprocess.run(command, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
log = 'commit-diff.log.gz'
(out / log).write_bytes(gzip.compress(result.stdout, mtime=0))
failed |= result.returncode != 0
record = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': head,
          'target': target, 'runtimes': runtimes, 'commitDiff': {'command': command,
          'exit': result.returncode, 'log': log, 'rawSha256': hashlib.sha256(result.stdout).hexdigest()},
          'exit': int(failed)}
(out / 'check-result.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
raise SystemExit(int(failed))
