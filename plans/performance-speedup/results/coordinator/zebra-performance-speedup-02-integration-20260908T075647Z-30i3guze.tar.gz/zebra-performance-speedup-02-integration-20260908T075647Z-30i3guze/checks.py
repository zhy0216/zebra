"""Integration checks; caller must hold run-load.py check."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = Path('/home/ubuntu/.herdr/worktrees/zebra/herdr-plan-performance-speedup-02-router')
HARNESS = '/home/ubuntu/workspace/zebra/bench/hot-path.ts'
BASELINE = 'a856cab47d4fd3102e976ce7a70166837837eea2'
failures = []

def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def record(value):
    with (OUT / 'checks.jsonl').open('a') as manifest:
        manifest.write(json.dumps(value) + '\n')
    print(json.dumps(value), flush=True)

def run(label, name, command, environment):
    log = OUT / f'{label}-{name}.log'
    started = stamp()
    print(f'START {label} {name}: {log}', flush=True)
    with log.open('wb') as output:
        result = subprocess.run(command, cwd=ROOT, env=environment,
                                stdout=output, stderr=subprocess.STDOUT)
    record(dict(runtime=label, name=name, command=command, cwd=str(ROOT),
                path=environment['PATH'], started=started, finished=stamp(),
                exit=result.returncode, log=str(log)))
    if result.returncode:
        failures.append(f'{label}-{name}')
    return result.returncode

focused = ['bun', 'test', 'packages/core/test/router',
           'packages/core/test/fuzz/router.test.ts', 'packages/core/test/app/method.test.ts',
           'packages/core/test/app/ws.test.ts', 'packages/core/test/ws.test.ts']
commands = [
    ('focused', focused),
    ('harness-check', ['bun', HARNESS, '--source-root', str(ROOT), '--suite', 'all', '--check']),
    ('typecheck', ['bun', 'run', 'typecheck']),
    ('lint', ['bun', 'run', 'lint']),
    ('diff-check', ['git', 'diff', '--check']),
    ('commit-diff-check', ['git', 'diff', 'master', 'HEAD', '--check']),
]
for version, binary_dir in [
    ('1.4.2', '/home/ubuntu/.bun/bin'),
    ('1.4.0', '/tmp/zebra-performance-speedup-01/runtime/bun-1.4.0'),
]:
    environment = dict(os.environ)
    environment['PATH'] = binary_dir + ':' + environment['PATH']
    record(dict(runtime=version, executable=shutil.which('bun', path=environment['PATH'])))
    runtime_script = 'console.log(JSON.stringify({version:Bun.version,revision:Bun.revision,execPath:process.execPath})); if(Bun.version !== ' + json.dumps(version) + ')process.exit(1)'
    if run(version, 'runtime', ['bun', '-e', runtime_script], environment):
        continue
    for name, command in commands:
        run(version, name, command, environment)

production = [path for path in subprocess.check_output(
    ['git', 'ls-files', 'packages'], cwd=ROOT, text=True).splitlines() if '/src/' in path]
production_command = ['git', 'diff', '--exit-code', BASELINE, 'HEAD', '--', *production]
run('source', 'baseline-equality', production_command, dict(os.environ))
initial = json.loads((OUT / 'initial-state.json').read_text())
identity = dict(productionFiles=len(production),
    routerSha256=hashlib.sha256((ROOT / 'packages/core/src/router/radix.ts').read_bytes()).hexdigest(),
    head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    master=subprocess.check_output(['git', 'rev-parse', 'master'], cwd=ROOT, text=True).strip(),
    evidenceTree=subprocess.check_output(['git', 'rev-parse', 'HEAD:plans/performance-speedup/results/02'], cwd=ROOT, text=True).strip(),
    status=subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True),
    finished=stamp())
identity['headUnchanged'] = identity['head'] == initial['head_before']
identity['masterUnchanged'] = identity['master'] == initial['master_before']
identity['evidenceUnchanged'] = identity['evidenceTree'] == initial['evidence_tree_before']
identity['clean'] = not identity['status']
record(identity)
for field in ['headUnchanged', 'masterUnchanged', 'evidenceUnchanged', 'clean']:
    if not identity[field]:
        failures.append(field)
record(dict(failures=failures, exit=int(bool(failures)), finished=stamp()))
raise SystemExit(bool(failures))
