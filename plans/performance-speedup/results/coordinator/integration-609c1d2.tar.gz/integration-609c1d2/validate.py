import datetime
import json
import os
from pathlib import Path
import subprocess
import sys

out=Path('/tmp/zebra-performance-speedup-01/integration-609c1d2')
root=Path.cwd()
commands=[
 ['bun','test','bench/test'],
 ['bun','run','bench/hot-path.ts','--source-root',str(root),'--suite','all','--check'],
 ['bun','run','bench/hot-path.ts','--source-root','/tmp/zebra-performance-speedup-01/baseline-a856cab','--suite','all','--check'],
 ['bun','run','typecheck'],
 ['bun','run','lint'],
 ['bun','test','packages/core/test/router','packages/core/test/fuzz/router.test.ts','packages/core/test/fuzz/path.test.ts','packages/core/test/app/fast-path.test.ts','packages/core/test/app/route-deps.test.ts','packages/core/test/app/method.test.ts','packages/core/test/http/request.test.ts','packages/core/test/http/request-helpers.test.ts','packages/core/test/di'],
]
failed=False
with (out/'checks.jsonl').open('w') as manifest:
 for label,bun_dir in [('142','/home/ubuntu/.bun/bin'),('140','/tmp/zebra-performance-speedup-01/runtime/bun-1.4.0')]:
  env=os.environ.copy()
  env['PATH']=bun_dir+os.pathsep+env['PATH']
  env.pop('HOT_PATH_TEST_EVIDENCE',None)
  for i,command in enumerate(commands):
   log=out/f'{label}-{i:02}.log'
   at=datetime.datetime.now(datetime.timezone.utc).isoformat()
   with log.open('w') as file:
    result=subprocess.run(command,cwd=root,env=env,stdout=file,stderr=subprocess.STDOUT)
   row={'at':at,'runtime':label,'command':command,'exit':result.returncode,'log':str(log)}
   manifest.write(json.dumps(row)+'\n');manifest.flush();print(json.dumps(row),flush=True)
   failed|=result.returncode!=0
 for i,command in enumerate([
  ['git','diff','--check','master','HEAD'],
  ['git','diff','--exit-code','a856cab47d4fd3102e976ce7a70166837837eea2','HEAD','--','packages','bench/scenarios.ts','bench/runner.ts','bench/zebra-bench.ts','bench/bench-regression.ts','bench/baseline.json','package.json','bun.lock'],
  ['git','diff','--exit-code','a1b26b79d5439e62819fdc0dad3d6419d6e00397','HEAD','--','bench/hot-path.ts','bench/hot-path-source.ts','bench/hot-path-fixtures.ts'],
 ]):
  log=out/f'git-{i:02}.log'
  with log.open('w') as file:
   result=subprocess.run(command,cwd=root,stdout=file,stderr=subprocess.STDOUT)
  row={'command':command,'exit':result.returncode,'log':str(log)}
  manifest.write(json.dumps(row)+'\n');manifest.flush();print(json.dumps(row),flush=True)
  failed|=result.returncode!=0
sys.exit(1 if failed else 0)
