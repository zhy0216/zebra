from pathlib import Path
import subprocess, os, json, datetime, shutil
out=Path(__file__).resolve().parent
env=os.environ.copy()
env['PATH']='/home/ubuntu/.bun/bin:'+env['PATH']
roots=[('task', '/home/ubuntu/.herdr/worktrees/zebra/herdr-plan-performance-speedup-03-metadata'), ('baseline','/tmp/zebra-performance-speedup-01/baseline-a856cab')]
records=[]
for name,cwd in roots:
    command=['bun','test','packages/session/test/store.test.ts']
    record={'name':name,'cwd':cwd,'command':command,'PATH':env['PATH'],'bun_resolved':shutil.which('bun',path=env['PATH']),'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'log':str(out/(name+'-store.log'))}
    print('START '+json.dumps(record),flush=True)
    with open(record['log'],'wb') as log:
        result=subprocess.run(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
    record['exit']=result.returncode
    record['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    records.append(record)
    (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print('END '+json.dumps(record),flush=True)
raise SystemExit(0 if all(r['exit']==0 for r in records) else 1)
