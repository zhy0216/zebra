# Task 03 coordinator full-test failure investigation

Task HEAD remains `01a5ca69330aa0f52dbd7f7d1513a9b77fb7e1d6`, parent `3b63455bb6a122203f5c4ec1596f46258312f706`. Integration remains on hold for coordinator review. No owned correction was identified and no repository files, TTLs, assertions, installs, baseline resources or commit bytes were changed. No full gates or metadata gates were repeated.

## Observed failure and likely mechanism

The coordinator's original Bun 1.4.2 (744846f84) `bun run test` / `bun test` result remains **1329 passed, 1 failed, 136112 assertions, 1330 tests across 117 files, 18.20 seconds total**, exit 1. The failing test was `MemoryStore > sweep is budget-bounded per call for large stores`; its reported **84.77 ms is that test's duration**, not the full-suite duration.

At `packages/session/test/store.test.ts:207`, immediately after 1,200 awaited `set` calls, `entries.size` was **597**, expected **1200**. This precedes `Bun.sleep(80)` and every post-sleep budget assertion. The unchanged test uses a **50 ms real-time TTL**. `MemoryStore.set` obtains `Date.now()`, sweeps expired entries, then inserts the next key with `expiresAt = now + ttl`. Thus entries can expire and be removed during insertion when setup crosses the TTL. This is the likely mechanism consistent with the assertion and elapsed duration; the log did not instrument insertion timestamps or individual sweeps, so it does not prove the exact clock progression or source of delay. CPU contention, scheduling, GC and wall-clock effects were not independently attributed. This is not evidence that the post-sleep 512-entry sweep budget is incorrect.

The exact original log is retained at `coordinator-full-test.log`, copied byte-for-byte from `/tmp/zebra-performance-speedup-f3263289/verify-03-01a5ca69/test.log`; SHA-256 `ac91a0deecb203b16d68aad47a2cd6a86e8e3911a05f471bec73c2b99d01e2d6`.

## Exact source and test equality

Direct byte comparisons, with SHA-256 and lengths in `byte-audit.json`, found the following files identical across Git blobs at `a856cab47d4fd3102e976ce7a70166837837eea2`, `609c1d298393c49b49e6c11537e55437c5f6a89f`, `3b63455bb6a122203f5c4ec1596f46258312f706`, and task HEAD, plus the task working files and frozen baseline working files:

- `packages/session/src/store.ts`: 4961 bytes, SHA-256 `343aef568179ab1db9e1ea16c7cf7ad26a2b2a5489fb180aed03e26cf6d8c23d`.
- `packages/session/test/store.test.ts`: 14147 bytes, SHA-256 `1f663f6355337c9bf00175bcb807b47de9cc5fb51d8b389c49a52c6990a62b1a`.
- `packages/core/src/http/request.ts`, `body.ts`, `errors.ts`, `bunfig.toml`, `package.json`, `bun.lock`, and `packages/session/package.json` also match in all six copies.

All baseline-tracked files under session source (6), session tests (10), and core source (38) also match the a856cab Git bytes in both tested directories. The frozen baseline is an installed source archive without `.git`; its identity is established here by comparison against Git objects, not an inferred `git rev-parse` from that directory.

## Owned metadata test isolation review

The only executable change in task 03 is `packages/core/test/http/request-metadata.test.ts`, unchanged at SHA-256 `f8de6555b2f0b3bdd0529b05c16a01fc41f9792e6fcd75c84d1ddbeca78d3a53`. It imports `bun:test`, `buildRequest`, and a body options type. Its runtime production import graph is request → body/errors, with no session/store import. The store suite directly imports its relative `../src/store.ts` and `bun:test`; the store module imports nothing else. The focused commands therefore load the source belonging to their respective cwd, with no package alias crossing source roots.

The new tests contain no mocks, spies, fake clocks, global/prototype mutations, hooks, environment edits, timers, fetches or servers. Mutations affect local request/header/query/Map objects; the module-local `limits` object is read by unchanged helpers. Abort listeners are attached only to local signals and their controllers are aborted synchronously. Tests await their body/helper operations and use `Promise.allSettled` for shared read failures. The imported modules' top-level initialization creates local defaults/decoders; it does not alter Date or shared store state. The existing store clock spies restore through `finally`.

In the failed full-test log, the store failure appears at line 745, while the metadata file is listed at line 1063 and all nine metadata tests pass through line 1072. That observed reporting order supports the isolation review; it is not a profiler or proof of all module-loading/GC behavior. Earlier related final-source checks already passed all nine metadata tests on both runtimes. They were not rerun here. No owned-test interference was found; these observations cannot rule out every process-wide runtime or scheduling effect.

## One focused suite per source root

Exactly two focused processes ran sequentially, each once, under this single correctness allocation:

```sh
python3 /tmp/zebra-performance-speedup-f3263289/run-load.py check python3 /tmp/zebra-performance-speedup-03-integration-3b63455-l9taxrrq/store-failure/run-store.py
```

Both used `PATH=/home/ubuntu/.bun/bin:<inherited PATH>` and resolved Bun to `/home/ubuntu/.bun/bin/bun`; both logs identify **Bun 1.4.2 (744846f84)**, matching the failed run. Exact command for each cwd:

```sh
bun test packages/session/test/store.test.ts
```

| Source / cwd | Exit | Actual result | Raw log |
| --- | ---: | --- | --- |
| Task: `/home/ubuntu/.herdr/worktrees/zebra/herdr-plan-performance-speedup-03-metadata` | 0 | 33 pass, 0 fail, 132 assertions; sweep-budget test passes | `task-store.log` |
| Frozen baseline: `/tmp/zebra-performance-speedup-01/baseline-a856cab` | 0 | 33 pass, 0 fail, 132 assertions; sweep-budget test passes | `baseline-store.log` |

Wrapper exit **0**. The allocation ran from requested time `2026-09-08T08:08:52.963660+00:00` to completion `2026-09-08T08:08:55.280618+00:00`. `commands.json` retains per-process UTC times, full PATH, exact cwd/argv and exits; `wrapper.json`, `run-store.py` and `runner.log` retain orchestration. No new benchmarks or minimum-runtime repetitions were scheduled. Test-reporter durations are retained as diagnostics, with no performance comparison claimed.

## Disposition

The original full failure remains recorded. The unchanged store's real-time setup assumption and passing isolated runs support one coordinator full retry justified by this failure; these focused passes do not substitute for that gate or erase the original result. No retry was launched by this worker. Keep integration on hold until the coordinator decides from this evidence. The task commit remains unchanged and its worktree is clean. The previously verified immutable aggregate harness SHA remains `b4a3feb23f5d26c8b6121d35e1b121b2b5ab6221b45a62ae4ddf42dd8a31a976`.
