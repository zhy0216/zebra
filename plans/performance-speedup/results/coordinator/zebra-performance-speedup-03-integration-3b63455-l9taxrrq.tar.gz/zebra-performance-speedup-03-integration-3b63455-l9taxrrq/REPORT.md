# Task 03 rebase verification

HEAD: `01a5ca69330aa0f52dbd7f7d1513a9b77fb7e1d6`.

One task commit rebased onto `3b63455bb6a122203f5c4ec1596f46258312f706`. Only conflict: `plans/performance-speedup/todos/README.md`, three hunks. Preserved master task 02 table/list/status and task 03 table/list/status. No production, shared harness, evidence, test or archived todo bytes changed. Worktree clean; master unchanged. No merge, push, root-checkout modification or resource cleanup.

All checks below ran sequentially under:

```sh
python3 /tmp/zebra-performance-speedup-f3263289/run-load.py check python3 /tmp/zebra-performance-speedup-03-integration-3b63455-l9taxrrq/run-checks.py
```

Bun 1.4.2 PATH prefix: `/home/ubuntu/.bun/bin`. Bun 1.4.0 PATH prefix: `/tmp/zebra-performance-speedup-01/runtime/bun-1.4.0`. Full expanded PATH and cwd are retained in each runtime command manifest. Wrapper exit: 0. Each semantic run: 175 passed, 0 failed, 1211 assertions.

| Bun | Exact command | Exit | Raw log |
| --- | --- | ---: | --- |
| 1.4.2 | `bun --version` | 0 | [integration-142-00.log.gz](/tmp/zebra-performance-speedup-03-integration-3b63455-l9taxrrq/integration-142-00.log.gz) |
| 1.4.2 | `bun test packages/core/test/http/request.test.ts packages/core/test/http/request-helpers.test.ts packages/core/test/http/request-metadata.test.ts packages/core/test/http/content-length.test.ts packages/core/test/contract packages/core/test/app/timeout.test.ts` | 0 | [integration-142-01.log.gz](/tmp/zebra-performance-speedup-03-integration-3b63455-l9taxrrq/integration-142-01.log.gz) |
| 1.4.2 | `bun /home/ubuntu/workspace/zebra/bench/hot-path.ts --source-root /tmp/zebra-performance-speedup-01/baseline-a856cab --suite all --check` | 0 | [integration-142-02.log.gz](/tmp/zebra-performance-speedup-03-integration-3b63455-l9taxrrq/integration-142-02.log.gz) |
| 1.4.2 | `bun /home/ubuntu/workspace/zebra/bench/hot-path.ts --source-root /home/ubuntu/.herdr/worktrees/zebra/herdr-plan-performance-speedup-03-metadata --suite all --check` | 0 | [integration-142-03.log.gz](/tmp/zebra-performance-speedup-03-integration-3b63455-l9taxrrq/integration-142-03.log.gz) |
| 1.4.2 | `bun run typecheck` | 0 | [integration-142-04.log.gz](/tmp/zebra-performance-speedup-03-integration-3b63455-l9taxrrq/integration-142-04.log.gz) |
| 1.4.2 | `bun run lint` | 0 | [integration-142-05.log.gz](/tmp/zebra-performance-speedup-03-integration-3b63455-l9taxrrq/integration-142-05.log.gz) |
| 1.4.2 | `git diff --check` | 0 | [integration-142-06.log.gz](/tmp/zebra-performance-speedup-03-integration-3b63455-l9taxrrq/integration-142-06.log.gz) |
| 1.4.0 | `bun --version` | 0 | [integration-140-00.log.gz](/tmp/zebra-performance-speedup-03-integration-3b63455-l9taxrrq/integration-140-00.log.gz) |
| 1.4.0 | `bun test packages/core/test/http/request.test.ts packages/core/test/http/request-helpers.test.ts packages/core/test/http/request-metadata.test.ts packages/core/test/http/content-length.test.ts packages/core/test/contract packages/core/test/app/timeout.test.ts` | 0 | [integration-140-01.log.gz](/tmp/zebra-performance-speedup-03-integration-3b63455-l9taxrrq/integration-140-01.log.gz) |
| 1.4.0 | `bun /home/ubuntu/workspace/zebra/bench/hot-path.ts --source-root /tmp/zebra-performance-speedup-01/baseline-a856cab --suite all --check` | 0 | [integration-140-02.log.gz](/tmp/zebra-performance-speedup-03-integration-3b63455-l9taxrrq/integration-140-02.log.gz) |
| 1.4.0 | `bun /home/ubuntu/workspace/zebra/bench/hot-path.ts --source-root /home/ubuntu/.herdr/worktrees/zebra/herdr-plan-performance-speedup-03-metadata --suite all --check` | 0 | [integration-140-03.log.gz](/tmp/zebra-performance-speedup-03-integration-3b63455-l9taxrrq/integration-140-03.log.gz) |
| 1.4.0 | `bun run typecheck` | 0 | [integration-140-04.log.gz](/tmp/zebra-performance-speedup-03-integration-3b63455-l9taxrrq/integration-140-04.log.gz) |
| 1.4.0 | `bun run lint` | 0 | [integration-140-05.log.gz](/tmp/zebra-performance-speedup-03-integration-3b63455-l9taxrrq/integration-140-05.log.gz) |
| 1.4.0 | `git diff --check` | 0 | [integration-140-06.log.gz](/tmp/zebra-performance-speedup-03-integration-3b63455-l9taxrrq/integration-140-06.log.gz) |

`git diff --check 3b63455bb6a122203f5c4ec1596f46258312f706 HEAD`: exit 0; raw log `/tmp/zebra-performance-speedup-03-integration-3b63455-l9taxrrq/committed-diff.log`.

Harness SHA-256: `b4a3feb23f5d26c8b6121d35e1b121b2b5ab6221b45a62ae4ddf42dd8a31a976`.

`before.json` and `rebase-audit.json` retain blob/state preservation checks; `README-conflict.diff` retains original conflicts; `rebase-continue.log` retains continuation output. `integration-142-commands.jsonl`, `integration-140-commands.jsonl`, `check-exits.json`, and `runner.log` retain exact checks and exits. Decompress `.log.gz` with `gzip -cd`.

## Coordinator full-test failure follow-up

Coordinator's full test on this HEAD failed the unchanged MemoryStore sweep-budget initial-size assertion (1329 pass, 1 fail). Integration is held. One focused store run in this tree and one in frozen baseline both passed on Bun 1.4.2 (33 tests, 132 assertions each; all exits 0) through the check lock. Source/test bytes match baseline; no owned metadata-test interference found. The likely mechanism is insertion setup crossing the real-time 50 ms TTL, with scheduling/clock cause unproven. No source/commit change or full retry was made here. Exact retained evidence and limitations: [store-failure/REPORT.md](/tmp/zebra-performance-speedup-03-integration-3b63455-l9taxrrq/store-failure/REPORT.md).
