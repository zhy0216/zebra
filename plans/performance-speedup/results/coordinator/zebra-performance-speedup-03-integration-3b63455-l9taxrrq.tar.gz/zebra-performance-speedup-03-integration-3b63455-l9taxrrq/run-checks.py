import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
out = Path(__file__).resolve().parent
root = Path('/home/ubuntu/.herdr/worktrees/zebra/herdr-plan-performance-speedup-03-metadata')
path = root / 'plans/performance-speedup/results/03/checks.py'
spec = importlib.util.spec_from_file_location('metadata_integration_checks', path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.OUT = out
original_path = os.environ['PATH']
exits = {}
for version, binary in [('142', '/home/ubuntu/.bun/bin'),
                        ('140', '/tmp/zebra-performance-speedup-01/runtime/bun-1.4.0')]:
    os.environ['PATH'] = binary + ':' + original_path
    sys.argv = [str(path), 'integration-' + version]
    try:
        module.main()
    except SystemExit as result:
        exits[version] = int(result.code or 0)
command = ['git', 'diff', '--check', '3b63455bb6a122203f5c4ec1596f46258312f706', 'HEAD']
result = subprocess.run(command, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(out / 'committed-diff.log').write_bytes(result.stdout)
exits['committed_diff'] = result.returncode
(out / 'check-exits.json').write_text(json.dumps({'exits': exits, 'committedDiffCommand': command}, indent=2) + '\n')
print(json.dumps(exits), flush=True)
raise SystemExit(any(exits.values()))
