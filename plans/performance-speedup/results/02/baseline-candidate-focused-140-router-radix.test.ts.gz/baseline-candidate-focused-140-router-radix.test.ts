import { expect, test } from "bun:test";
import { Router } from "/tmp/zebra-performance-speedup-01/baseline-a856cab/packages/core/src/router/radix.ts";
test("allowed methods union every matching branch without changing route precedence", () => {
  const router = new Router<string>();
  router.add("GET", "/users/me", "static");
  router.add("POST", "/users/:id", "param");
  router.add("PATCH", "/users/*rest", "wildcard");
  router.add("GET", "/users/*rest", "fallback");
  expect(router.allowedMethods("/users/me")).toEqual(["GET", "POST", "PATCH"]);
  expect(router.find("GET", "/users/me")?.handler).toBe("static");
  expect(router.find("POST", "/users/me")?.params).toEqual({ id: "me" });
  expect(router.allowedMethods("/users/other")).toEqual(["POST", "PATCH", "GET"]);
  expect(router.allowedMethods("/users/a/b")).toEqual(["PATCH", "GET"]);
  expect(router.allowedMethods("/missing")).toBeNull();
});

test("allowed methods include terminal routes and empty wildcards", () => {
  const router = new Router<string>();
  router.add("GET", "/files", "exact");
  router.add("PUT", "/files/*rest", "empty-wildcard");
  expect(router.allowedMethods("/files")).toEqual(["GET", "PUT"]);
  expect(router.allowedMethods("/files/")).toEqual(["GET", "PUT"]);
  expect(router.find("PUT", "/files")?.params).toEqual({ rest: "" });
});

test("static route match", () => {
  const r = new Router<string>();
  r.add("GET", "/hello", "h");
  expect(r.find("GET", "/hello")).toEqual({ handler: "h", params: {} });
});

test("param route extracts variables", () => {
  const r = new Router<string>();
  r.add("GET", "/blogs/:id", "show");
  const m = r.find("GET", "/blogs/42");
  expect(m).toEqual({ handler: "show", params: { id: "42" } });
});

test("multiple params", () => {
  const r = new Router<string>();
  r.add("GET", "/blogs/:id/comments/:cid", "h");
  expect(r.find("GET", "/blogs/1/comments/2")).toEqual({
    handler: "h",
    params: { id: "1", cid: "2" },
  });
});

test("static beats param when both match", () => {
  const r = new Router<string>();
  r.add("GET", "/blogs/:id", "any");
  r.add("GET", "/blogs/new", "new");
  expect(r.find("GET", "/blogs/new")?.handler).toBe("new");
  expect(r.find("GET", "/blogs/42")?.handler).toBe("any");
});

test("method mismatch returns null", () => {
  const r = new Router<string>();
  r.add("GET", "/x", "g");
  expect(r.find("POST", "/x")).toBeNull();
});

test("wildcard captures rest", () => {
  const r = new Router<string>();
  r.add("GET", "/files/*path", "h");
  expect(r.find("GET", "/files/a/b/c.txt")).toEqual({
    handler: "h",
    params: { path: "a/b/c.txt" },
  });
});

test("unknown route returns null", () => {
  const r = new Router<string>();
  r.add("GET", "/a", "h");
  expect(r.find("GET", "/b")).toBeNull();
});

test("parameter names belong to each method's registered route", () => {
  const r = new Router<string>();
  r.add("GET", "/users/:id", "get");
  r.add("POST", "/users/:userId", "post");
  expect(r.find("GET", "/users/1")?.params).toEqual({ id: "1" });
  expect(r.find("POST", "/users/2")?.params).toEqual({ userId: "2" });
});

test("param values are percent-decoded", () => {
  const r = new Router<string>();
  r.add("GET", "/users/:id", "h");
  expect(r.find("GET", "/users/foo%20bar")?.params).toEqual({ id: "foo bar" });
  // Encoded separators decode into the value only; matching happens on the
  // raw segment, so %2F never reaches the router as a path split.
  expect(r.find("GET", "/users/a%2Fb")?.params).toEqual({ id: "a/b" });
});

test("malformed percent-encoding keeps the raw value", () => {
  const r = new Router<string>();
  r.add("GET", "/users/:id", "h");
  expect(r.find("GET", "/users/%zz")?.params).toEqual({ id: "%zz" });
});

test("wildcard captures are not percent-decoded", () => {
  const r = new Router<string>();
  r.add("GET", "/files/*path", "h");
  expect(r.find("GET", "/files/a%2Fb/c%20d")?.params).toEqual({ path: "a%2Fb/c%20d" });
});

test("duplicate registration with the same parameter layout throws", () => {
  const r = new Router<string>();
  r.add("GET", "/a/:id", "one");
  expect(() => r.add("GET", "/a/:slug", "two")).toThrow(/Duplicate route/);
});

test("a param segment wins over a wildcard for a single-segment path", () => {
  const r = new Router<string>();
  r.add("GET", "/x/:id", "param");
  r.add("GET", "/x/*rest", "wildcard");
  expect(r.find("GET", "/x/42")?.handler).toBe("param");
  // Deeper paths can only match the wildcard.
  expect(r.find("GET", "/x/a/b")?.handler).toBe("wildcard");
  expect(r.find("GET", "/x/a/b")?.params).toEqual({ rest: "a/b" });
});

test("trailing slashes are ignored by the matcher", () => {
  const r = new Router<string>();
  r.add("GET", "/a", "h");
  expect(r.find("GET", "/a/")?.handler).toBe("h");
  expect(r.find("GET", "///a///")?.handler).toBe("h");
});

test("static routes keep encoded spelling and interior empty segments", () => {
  const router = new Router<string>();
  router.add("get", "///a%2Fb///", "encoded");
  router.add("GET", "/a/b", "separated");
  router.add("GET", "/a//b", "empty-segment");
  router.add("GET", "/%GG", "malformed-static");
  router.add("GET", "/:value", "parameter");
  for (const edges of ["", "/", "///"]) {
    expect(router.find("gEt", `${edges}a%2Fb${edges}`)).toEqual({
      handler: "encoded",
      params: {},
    });
    expect(router.find("GET", `${edges}a/b${edges}`)?.handler).toBe("separated");
    expect(router.find("GET", `${edges}a//b${edges}`)?.handler).toBe("empty-segment");
    expect(router.find("GET", `${edges}%GG${edges}`)?.handler).toBe("malformed-static");
  }
  expect(router.find("GET", "/a%2fb")).toEqual({
    handler: "parameter",
    params: { value: "a/b" },
  });
  expect(router.find("GET", "/%zz")?.params).toEqual({ value: "%zz" });
});

test("static method misses retain branch precedence, method names and Allow order", () => {
  const router = new Router<string>();
  router.add("PATCH", "/a/*rest", "wildcard");
  router.add("POST", "/a/:postId", "post-param");
  router.add("BREW", "/a/:brewId", "custom-param");
  router.add("GET", "/a/fixed", "static");
  router.add("PUT", "/a/fixed", "static-put");
  router.add("POST", "/a/*rest", "post-wildcard");
  expect(router.find("post", "///a/fixed///")).toEqual({
    handler: "post-param",
    params: { postId: "fixed" },
  });
  expect(router.find("brew", "/a/fixed")?.params).toEqual({ brewId: "fixed" });
  expect(router.find("PATCH", "/a/fixed")?.params).toEqual({ rest: "fixed" });
  expect(router.find("POST", "/a")).toEqual({
    handler: "post-wildcard",
    params: { rest: "" },
  });
  expect(router.find("POST", "/a/%2F/%GG")?.params).toEqual({ rest: "%2F/%GG" });
  expect(router.find("HEAD", "/a/fixed")).toBeNull();
  expect(router.allowedMethods("///a/fixed///")).toEqual(["GET", "PUT", "POST", "BREW", "PATCH"]);
});

test("root routes and normalized duplicates retain successful registrations", () => {
  const router = new Router<string>();
  router.add("GET", "///", "root");
  router.add("POST", "/*rest", "wildcard");
  router.add("PUT", "", "put-root");
  expect(() => router.add("get", "/", "duplicate")).toThrow(/Duplicate route/);
  router.add("GET", "a//b/", "interior");
  expect(() => router.add("get", "///a//b///", "duplicate")).toThrow(/Duplicate route/);
  for (const path of ["", "/", "////"]) {
    expect(router.find("GET", path)).toEqual({ handler: "root", params: {} });
    expect(router.find("POST", path)).toEqual({ handler: "wildcard", params: { rest: "" } });
    expect(router.allowedMethods(path)).toEqual(["GET", "PUT", "POST"]);
  }
  expect(router.find("GET", "/a//b")?.handler).toBe("interior");
});

test("static and captured matches return independently mutable null-prototype params", () => {
  const router = new Router<unknown>();
  router.add("GET", "/fixed", undefined);
  router.add("POST", "/:__proto__", false);
  router.add("PUT", "/*rest", 0);
  for (const method of ["GET", "POST", "PUT"]) {
    const first = router.find(method, "/fixed")!;
    const second = router.find(method, "/fixed")!;
    expect(first).not.toBe(second);
    expect(first.params).not.toBe(second.params);
    expect(Object.getPrototypeOf(first.params)).toBeNull();
    const original = { ...second.params };
    first.params.extra = "changed";
    first.params.__proto__ = "own value";
    expect(Reflect.deleteProperty(first.params, "rest")).toBe(true);
    expect(second.params).toEqual(original);
    expect(router.find(method, "/fixed")).toEqual(second);
  }
  expect(router.find("GET", "/fixed")?.handler).toBeUndefined();
  expect(router.find("POST", "/fixed")?.handler).toBe(false);
  expect(router.find("PUT", "/fixed")?.handler).toBe(0);
});
